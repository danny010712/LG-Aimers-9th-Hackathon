"""평가 서버 추론 스크립트.

./data/test.csv 로드 → CatBoost 시드 앙상블 추론 → ./output/submission.csv 저장.
각 행 독립 예측 (test 내부 행 간 통계 사용 안 함).
피처 생성은 features.py 를 학습과 공유한다.

=== league-rate baseline 추가 ===
⚠️ meta["league_baseline"]["enabled"]가 True면, 성공모델(model_*.cbm)은
baseline 위에서 잔차만 학습된 상태다. CatBoost baseline은 .cbm에
저장되지 않으므로(실측 확인), 여기서도 학습 때와 똑같은 방식으로
baseline을 다시 계산해 Pool에 넣어야 한다. 안 넣으면 예측 평균이
크게 틀어진다 — 이 부분이 이번 변경에서 가장 중요한 포인트다.
mr_*.cbm / wayoff_*.cbm(보조모델)은 baseline을 쓰지 않는다(변경 없음).
"""
import json
import os
import sys

import numpy as np
import pandas as pd
from catboost import CatBoostClassifier, Pool

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
from features import engineer, prepare  # noqa: E402
import cond  # noqa: E402
import league_rate as lr  # noqa: E402

ID, TARGET = "row_id", "control_success"


def main():
    data_dir = "./data"
    test = pd.read_csv(os.path.join(data_dir, "test.csv"), encoding="utf-8-sig")
    sub = pd.read_csv(os.path.join(data_dir, "sample_submission.csv"),
                      encoding="utf-8-sig")

    meta = json.load(open(os.path.join(BASE, "model", "meta.json"),
                          encoding="utf-8"))
    feature_cols = meta["feature_cols"]
    cat_cols = meta["cat_cols"]

    # global_mean은 학습 때 쓴 값을 그대로 재사용해야 한다 (test에서 재계산 금지).
    fe = engineer(test.drop(columns=[ID]), meta["global_mean"])
    if meta.get("use_cond"):
        tables = {n: pd.read_csv(os.path.join(BASE, "model", f"cond_{n}.csv"),
                                 encoding="utf-8")
                  for n, _, _ in cond.SPECS}
        fe = cond.apply_tables(fe, tables)
    X = prepare(fe, feature_cols, cat_cols)
    ci = [X.columns.get_loc(c) for c in cat_cols]

    # ---- league-rate baseline (성공모델 전용) ----
    lb = meta.get("league_baseline", {"enabled": False})
    main_baseline = None
    if lb.get("enabled"):
        # test는 raw test.csv에서 season/game_type을 봐야 한다 (fe/X는 문자열
        # 캐스팅 등으로 원본과 dtype이 달라질 수 있으므로 원본 test에서 가져옴).
        raw = test[["season"] + (["game_type"] if "game_type" in lb["group_cols"]
                                 else [])].copy()
        table, group_cols = lr.table_from_json(lb)
        # 2025(test) 시즌은 table에 없으므로 자동으로 held_out_estimate()가
        # 적용된다 (assign_baseline_logit 내부에서 "not in table.index" 분기).
        # override(외부 도메인 추정치, 10문서 §6-C)를 우선 쓴다.
        main_baseline = lr.assign_baseline_logit(
            raw, table, group_cols, held_out_season=None,
            override=lb.get("test_override"),
            f_min_season=lb.get("f_min_season", 2023))
        print(f" league_rate baseline 적용: 그룹={group_cols} "
              f"평균(로짓)={main_baseline.mean():+.4f} "
              f"(override={lb.get('test_override')})")

    pool_main = Pool(X, cat_features=ci, baseline=main_baseline)
    pool_aux = Pool(X, cat_features=ci)   # mr/wayoff는 baseline 없음(변경 없음)

    def avg_proba(prefix, seeds, pool):
        ps = []
        for sd in seeds:
            m = CatBoostClassifier()
            m.load_model(os.path.join(BASE, "model", f"{prefix}{sd}.cbm"))
            ps.append(m.predict_proba(pool)[:, 1])
        return np.mean(ps, axis=0)

    p = np.clip(avg_proba("model_", meta["seeds"], pool_main), 1e-6, 1 - 1e-6)

    off = meta.get("offset")
    if off:
        # 실패모드 offset (08 문서 §5). y=0 ⟺ (M∪R) ⊎ W 를 이용해
        # 합에서 상쇄되던 성분 정보를 되돌린다.
        # a=1·d=0 고정 — 스케일/절편을 적합하면 그게 calibration이 되어
        # 시즌 간 전이가 깨진다(자기연도 +53.8 → 한 해 건너 −210~−638).
        # mu는 학습 때 저장한 값. test에서 평균을 내면 규정 위반이다.
        def logit(q):
            q = np.clip(q, 1e-6, 1 - 1e-6)
            return np.log(q / (1 - q))

        z = (logit(p)
             + off["b"] * (logit(avg_proba("mr_", off["seeds"], pool_aux))
                           - off["mu_mr"])
             + off["c"] * (logit(avg_proba("wayoff_", off["seeds"], pool_aux))
                           - off["mu_wayoff"]))
        p = np.clip(1 / (1 + np.exp(-z)), 1e-6, 1 - 1e-6)

    shift = meta.get("logit_shift")
    if shift:
        # 시즌 base rate 하락 보정 (08 §5-6). league-rate baseline이 이미
        # 평균 수준 대부분을 잡아준다면, 이 값은 아주 작은 잔여 보정이어야
        # 정상이다(0 또는 0에 가까운 값). 큰 폭이면 baseline이 기대만큼
        # 작동하지 않았다는 신호 — build_shift.py의 진단 출력을 볼 것.
        p = np.clip(1 / (1 + np.exp(-(np.log(p / (1 - p)) + shift))), 1e-6, 1 - 1e-6)

    pred_map = dict(zip(test[ID], p))
    sub[TARGET] = [pred_map.get(rid, 0.5) for rid in sub[ID]]

    os.makedirs("./output", exist_ok=True)
    sub.to_csv("./output/submission.csv", index=False, encoding="utf-8")
    print(f"Saved ./output/submission.csv rows={len(sub)} "
          f"seeds={len(meta['seeds'])} offset={'Y' if off else 'N'} "
          f"league_baseline={'Y' if lb.get('enabled') else 'N'} "
          f"mean={p.mean():.4f}")


if __name__ == "__main__":
    main()
